import React from 'react';
import { NavLink } from 'react-router-dom';
import { Sprout, Scan, User } from 'lucide-react';

const BottomNav = () => {
    return (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 pb-safe z-50">
            <div className="flex justify-around items-center h-16 max-w-md mx-auto">
                <NavLink
                    to="/harvest"
                    className={({ isActive }) =>
                        `flex flex-col items-center justify-center w-full h-full space-y-1 ${isActive ? 'text-farm-green-600' : 'text-gray-400 hover:text-gray-600'}`
                    }
                >
                    <Sprout size={24} />
                    <span className="text-xs font-medium">Harvest</span>
                </NavLink>

                <NavLink
                    to="/scanner"
                    className={({ isActive }) =>
                        `flex flex-col items-center justify-center w-full h-full space-y-1 ${isActive ? 'text-farm-green-600' : 'text-gray-400 hover:text-gray-600'}`
                    }
                >
                    <Scan size={24} />
                    <span className="text-xs font-medium">Scanner</span>
                </NavLink>

                <NavLink
                    to="/profile"
                    className={({ isActive }) =>
                        `flex flex-col items-center justify-center w-full h-full space-y-1 ${isActive ? 'text-farm-green-600' : 'text-gray-400 hover:text-gray-600'}`
                    }
                >
                    <User size={24} />
                    <span className="text-xs font-medium">Profile</span>
                </NavLink>
            </div>
        </div>
    );
};

export default BottomNav;
