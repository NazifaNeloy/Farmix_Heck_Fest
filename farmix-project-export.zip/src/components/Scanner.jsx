import React, { useEffect, useRef, useState } from 'react';
import { useImageClassifier } from '../hooks/useImageClassifier';
import { Camera, AlertTriangle, CheckCircle, Loader } from 'lucide-react';

const Scanner = () => {
    const videoRef = useRef(null);
    const { model, predict, loading, error } = useImageClassifier();
    const [predictions, setPredictions] = useState([]);
    const [alert, setAlert] = useState(null); // 'rotten' | 'fresh' | null
    const [isScanning, setIsScanning] = useState(false);

    useEffect(() => {
        startCamera();
        return () => stopCamera();
    }, []);

    useEffect(() => {
        let interval;
        if (model && isScanning && videoRef.current) {
            interval = setInterval(async () => {
                if (videoRef.current.readyState === 4) {
                    const prediction = await predict(videoRef.current);
                    setPredictions(prediction);
                    analyzePrediction(prediction);
                }
            }, 500);
        }
        return () => clearInterval(interval);
    }, [model, isScanning]);

    const startCamera = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                setIsScanning(true);
            }
        } catch (err) {
            console.error("Camera error:", err);
        }
    };

    const stopCamera = () => {
        if (videoRef.current && videoRef.current.srcObject) {
            const tracks = videoRef.current.srcObject.getTracks();
            tracks.forEach(track => track.stop());
            setIsScanning(false);
        }
    };

    const analyzePrediction = (prediction) => {
        // Assuming classes are "Rotten" and "Fresh" based on Teachable Machine standard
        // We need to check the actual class names from metadata or just assume index 0/1 if known.
        // Usually prediction is array of { className: string, probability: number }

        const rotten = prediction.find(p => p.className.toLowerCase().includes('rotten'));
        const fresh = prediction.find(p => p.className.toLowerCase().includes('fresh'));

        if (rotten && rotten.probability > 0.8) {
            setAlert('rotten');
        } else if (fresh && fresh.probability > 0.8) {
            setAlert('fresh');
        } else {
            setAlert(null);
        }
    };

    if (loading) return <div className="flex justify-center p-10"><Loader className="animate-spin text-farm-green-600" /></div>;
    if (error) return <div className="text-red-500 p-4">Failed to load AI Model. Check connection or files.</div>;

    return (
        <div className="flex flex-col items-center w-full max-w-md mx-auto">
            <div className="relative w-full aspect-square bg-black rounded-2xl overflow-hidden shadow-lg mb-6">
                <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                />

                {/* Overlay Badges */}
                {alert === 'rotten' && (
                    <div className="absolute inset-0 bg-red-500/30 flex items-center justify-center animate-pulse">
                        <div className="bg-white p-4 rounded-xl shadow-xl flex flex-col items-center text-red-600">
                            <AlertTriangle size={48} className="mb-2" />
                            <h2 className="text-xl font-bold">High Moisture/Mold!</h2>
                            <p className="text-sm text-gray-600">Action: Dry Immediately</p>
                        </div>
                    </div>
                )}

                {alert === 'fresh' && (
                    <div className="absolute top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-full flex items-center gap-2 shadow-lg">
                        <CheckCircle size={20} />
                        <span className="font-bold">Healthy Crop</span>
                    </div>
                )}
            </div>

            {/* Debug/Stats View */}
            <div className="w-full bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                <h3 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">Live Analysis</h3>
                <div className="space-y-2">
                    {predictions.map((p, i) => (
                        <div key={i} className="flex items-center gap-3">
                            <div className="w-24 text-sm font-medium truncate">{p.className}</div>
                            <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                                <div
                                    className={`h-full ${p.className.toLowerCase().includes('rotten') ? 'bg-red-500' : 'bg-green-500'}`}
                                    style={{ width: `${p.probability * 100}%` }}
                                />
                            </div>
                            <div className="w-12 text-xs text-gray-500 text-right">{(p.probability * 100).toFixed(0)}%</div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Scanner;
