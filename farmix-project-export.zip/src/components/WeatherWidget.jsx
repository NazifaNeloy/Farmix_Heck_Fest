import React, { useState, useEffect } from 'react';
import { fetchForecast } from '../services/weatherService';
import { CloudRain, Sun, Cloud, AlertTriangle, CheckCircle, Search } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const WeatherWidget = () => {
    const { userData } = useAuth();
    const [forecast, setForecast] = useState([]);
    const [district, setDistrict] = useState(userData?.location || 'Dhaka');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadWeather();
    }, []);

    const loadWeather = async () => {
        setLoading(true);
        const data = await fetchForecast(district);
        setForecast(data);
        setLoading(false);
    };

    const handleSearch = (e) => {
        e.preventDefault();
        loadWeather();
    };

    const getWeatherIcon = (condition) => {
        switch (condition.toLowerCase()) {
            case 'rain': return <CloudRain className="text-blue-500" />;
            case 'clear': return <Sun className="text-yellow-500" />;
            case 'clouds': return <Cloud className="text-gray-500" />;
            default: return <Sun className="text-yellow-500" />;
        }
    };

    const getAdvisoryColor = (type) => {
        switch (type) {
            case 'danger': return 'bg-red-100 text-red-700 border-red-200';
            case 'warning': return 'bg-orange-100 text-orange-700 border-orange-200';
            case 'success': return 'bg-green-100 text-green-700 border-green-200';
            default: return 'bg-gray-100 text-gray-700';
        }
    };

    if (loading) return <div className="p-4 bg-white rounded-2xl shadow-sm animate-pulse h-48"></div>;

    const current = forecast[0];

    return (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-6">
            <div className="flex justify-between items-start mb-6">
                <div>
                    <h3 className="text-lg font-bold text-farm-green-900">Weather Forecast</h3>
                    <form onSubmit={handleSearch} className="flex items-center gap-2 mt-1">
                        <input
                            type="text"
                            value={district}
                            onChange={(e) => setDistrict(e.target.value)}
                            className="text-sm text-gray-500 border-b border-gray-300 focus:border-farm-green-500 outline-none w-24"
                        />
                        <button type="submit" className="text-gray-400 hover:text-farm-green-500">
                            <Search size={14} />
                        </button>
                    </form>
                </div>
                <div className="text-right">
                    <div className="text-3xl font-bold text-gray-900">{current?.temp}°C</div>
                    <div className="text-sm text-gray-500">{current?.condition}</div>
                </div>
            </div>

            {/* Main Advisory */}
            <div className={`p-4 rounded-xl border mb-6 flex items-start gap-3 ${getAdvisoryColor(current?.advisory.type)}`}>
                <AlertTriangle size={20} className="shrink-0 mt-0.5" />
                <div>
                    <div className="font-bold">Advisory (পরামর্শ)</div>
                    <div className="text-sm">{current?.advisory.text}</div>
                </div>
            </div>

            {/* 5-Day Forecast */}
            <div className="grid grid-cols-5 gap-2">
                {forecast.map((day, index) => (
                    <div key={index} className="text-center p-2 rounded-lg hover:bg-gray-50 transition-colors">
                        <div className="text-xs text-gray-500 mb-1">{day.date}</div>
                        <div className="flex justify-center mb-1">
                            {getWeatherIcon(day.condition)}
                        </div>
                        <div className="text-sm font-bold">{day.temp}°</div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default WeatherWidget;
