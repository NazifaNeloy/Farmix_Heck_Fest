export const translations = {
    en: {
        hero: {
            headline: "Save Your Harvest, Secure Your Profit",
            subheadline: "Bangladesh loses 4.5 million tonnes of food annually. Be the change.",
            cta: "Get Started",
        },
        workflow: {
            title: "How it Works",
            steps: [
                { title: "Data", desc: "Input your crop details" },
                { title: "Warning", desc: "Get early alerts" },
                { title: "Action", desc: "Take preventive measures" },
                { title: "Saved Food", desc: "Maximize your yield" },
            ]
        },
        nav: {
            home: "Home",
            about: "About",
            contact: "Contact",
        }
    },
    bn: {
        hero: {
            headline: "আপনার ফসল বাঁচান, লাভ নিশ্চিত করুন",
            subheadline: "বাংলাদেশে প্রতি বছর ৪.৫ মিলিয়ন টন খাদ্য নষ্ট হয়। পরিবর্তন হোন।",
            cta: "শুরু করুন",
        },
        workflow: {
            title: "কিভাবে কাজ করে",
            steps: [
                { title: "তথ্য", desc: "আপনার ফসলের বিবরণ দিন" },
                { title: "সতর্কতা", desc: "আগাম সতর্কতা পান" },
                { title: "পদক্ষেপ", desc: "প্রতিরোধমূলক ব্যবস্থা নিন" },
                { title: "খাদ্য রক্ষা", desc: "আপনার ফলন সর্বোচ্চ করুন" },
            ]
        },
        nav: {
            home: "হোম",
            about: "সম্পর্কে",
            contact: "যোগাযোগ",
        }
    }
};
