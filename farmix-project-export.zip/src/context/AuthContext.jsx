import React, { createContext, useContext, useEffect, useState } from 'react';
import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [userData, setUserData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
            setUser(currentUser);
            if (currentUser) {
                try {
                    // Create a timeout promise
                    const timeoutPromise = new Promise((_, reject) =>
                        setTimeout(() => reject(new Error("Firestore timeout")), 5000)
                    );

                    // Race getDoc against timeout
                    const userDoc = await Promise.race([
                        getDoc(doc(db, "users", currentUser.uid)),
                        timeoutPromise
                    ]);

                    if (userDoc.exists()) {
                        setUserData(userDoc.data());
                    } else {
                        throw new Error("Doc does not exist");
                    }
                } catch (err) {
                    console.warn("Profile fetch failed or timed out, using fallback:", err);
                    // Fallback on error/timeout
                    setUserData({
                        uid: currentUser.uid,
                        email: currentUser.email,
                        name: currentUser.displayName || "User",
                        badges: []
                    });
                }
            } else {
                setUserData(null);
            }
            setLoading(false);
        });

        return unsubscribe;
    }, []);

    const signup = async (email, password, name, phone, language) => {
        console.log("Starting signup process...");
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        console.log("User created in Auth:", user.uid);

        const newProfile = {
            uid: user.uid,
            name,
            phone,
            language,
            email,
            badges: [],
            location: null,
            createdAt: new Date().toISOString()
        };

        // Optimistically set user data so UI updates immediately
        setUserData(newProfile);

        // Create user profile in Firestore (Non-blocking / Background)
        setDoc(doc(db, "users", user.uid), newProfile)
            .then(() => console.log("Profile saved to Firestore"))
            .catch((err) => console.error("Failed to save profile to Firestore:", err));

        return user;
    };

    const login = (email, password) => {
        return signInWithEmailAndPassword(auth, email, password);
    };

    const logout = () => {
        return signOut(auth);
    };

    const value = {
        user,
        userData,
        signup,
        login,
        logout,
        loading
    };

    return (
        <AuthContext.Provider value={value}>
            {!loading && children}
        </AuthContext.Provider>
    );
};
