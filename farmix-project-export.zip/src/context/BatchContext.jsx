import React, { createContext, useContext, useState, useEffect } from 'react';
import { collection, addDoc, query, where, getDocs, writeBatch } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthContext';

const BatchContext = createContext();

export const useBatch = () => useContext(BatchContext);

export const BatchProvider = ({ children }) => {
    const { user } = useAuth();
    const [batches, setBatches] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isOnline, setIsOnline] = useState(navigator.onLine);

    // Load from LocalStorage on mount
    useEffect(() => {
        const localBatches = localStorage.getItem('farmix_batches');
        if (localBatches) {
            setBatches(JSON.parse(localBatches));
        }
        setLoading(false);
    }, []);

    // Monitor Online Status
    useEffect(() => {
        const handleOnline = () => setIsOnline(true);
        const handleOffline = () => setIsOnline(false);

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);

    // Sync Logic
    useEffect(() => {
        if (isOnline && user) {
            syncBatches();
        }
    }, [isOnline, user]);

    // Save to LocalStorage whenever batches change
    useEffect(() => {
        localStorage.setItem('farmix_batches', JSON.stringify(batches));
    }, [batches]);

    const syncBatches = async () => {
        const unsyncedBatches = batches.filter(b => !b.synced);
        if (unsyncedBatches.length === 0) return;

        try {
            const batchWrite = writeBatch(db);
            const updatedBatches = [...batches];

            for (const batchItem of unsyncedBatches) {
                // Prepare data for Firestore (remove local-only fields if any)
                const { id, synced, ...dataToUpload } = batchItem;

                // Add to Firestore
                await addDoc(collection(db, 'batches'), {
                    ...dataToUpload,
                    userId: user.uid,
                    createdAt: new Date().toISOString()
                });

                // Update local state to synced
                const index = updatedBatches.findIndex(b => b.id === batchItem.id);
                if (index !== -1) {
                    updatedBatches[index].synced = true;
                }
            }

            setBatches(updatedBatches);
            console.log('Sync complete');
        } catch (error) {
            console.error('Sync failed:', error);
        }
    };

    const addBatch = (batchData) => {
        const newBatch = {
            id: crypto.randomUUID(),
            ...batchData,
            userId: user?.uid,
            synced: false,
            createdAt: new Date().toISOString()
        };

        setBatches(prev => [newBatch, ...prev]);

        // Try to sync immediately if online
        if (isOnline && user) {
            // We rely on the useEffect to pick this up or we can trigger it manually
            // But since state update is async, the useEffect [batches] dependency might be tricky with the sync logic loop.
            // For simplicity, let's just let the next sync cycle handle it or force a check.
            // Actually, the useEffect [isOnline] only triggers on status change. 
            // We should probably trigger sync in a separate effect or call it here.
            // Let's rely on a separate effect that watches 'batches' and 'isOnline'.
        }
    };

    // Effect to sync when new unsynced batches are added and we are online
    useEffect(() => {
        if (isOnline && user && batches.some(b => !b.synced)) {
            syncBatches();
        }
    }, [batches, isOnline, user]);


    const value = {
        batches,
        addBatch,
        isOnline
    };

    return (
        <BatchContext.Provider value={value}>
            {children}
        </BatchContext.Provider>
    );
};
