import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useBatch } from '../context/BatchContext';
import AddBatchForm from '../components/AddBatchForm';
import BatchList from '../components/BatchList';
import WeatherWidget from '../components/WeatherWidget';
import RiskMeter from '../components/RiskMeter';
import { Wifi, WifiOff } from 'lucide-react';
import BottomNav from '../components/BottomNav';

const HarvestPage = () => {
    const { isOnline } = useBatch();
    // In a real app, these would come from the WeatherWidget or a shared WeatherContext
    // For demo, we'll use some default/mock values or we could lift state up.
    // Let's assume we want to show the risk based on "Current" conditions.
    // Since WeatherWidget fetches data internally, we might want to refactor to share data.
    // BUT for now, to keep it simple as per instructions, I'll pass some demo props 
    // or ideally, WeatherWidget should probably be the one fetching and we pass data down.
    // However, to avoid refactoring WeatherWidget too much, let's just render RiskMeter 
    // with some sensible defaults or maybe we can make WeatherWidget accept an "onDataLoad" prop.

    // Let's stick to the simplest integration: Just render it. 
    // I'll add a small "Simulation" toggle for the user to see the risk meter change? 
    // Or just hardcode "High Risk" scenario for the demo as requested by the "Logic" description?
    // The prompt says "If humidity > 80...". 
    // I will pass hardcoded values that trigger a "Medium" risk for now to show it works, 
    // or better, I'll add a small "Simulate Weather" section in the RiskMeter itself? No, that's too complex.

    // Best approach: Pass props. I'll use state here to simulate.
    const [weatherData] = useState({ humidity: 85, temp: 32, rainIn24Hours: true });

    return (
        <div className="min-h-screen bg-farm-green-50 p-4 pb-24">
            <div className="max-w-md mx-auto">
                {/* Header */}
                <div className="flex justify-between items-center mb-6">
                    <div>
                        <h1 className="text-2xl font-bold text-farm-green-900">Dashboard</h1>
                        <p className="text-sm text-gray-500">Welcome back, Farmer</p>
                    </div>
                    <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${isOnline ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-600'}`}>
                        {isOnline ? <Wifi size={14} /> : <WifiOff size={14} />}
                        {isOnline ? 'Online' : 'Offline'}
                    </div>
                </div>

                {/* Quick Actions */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                    <button onClick={() => document.getElementById('add-batch-btn').click()} className="bg-farm-green-100 p-4 rounded-xl flex flex-col items-center justify-center text-farm-green-800 hover:bg-farm-green-200 transition-colors">
                        <span className="text-2xl mb-1">🌱</span>
                        <span className="font-bold text-sm">Add Crop</span>
                    </button>
                    <Link to="/scanner" className="bg-blue-100 p-4 rounded-xl flex flex-col items-center justify-center text-blue-800 hover:bg-blue-200 transition-colors">
                        <span className="text-2xl mb-1">📸</span>
                        <span className="font-bold text-sm">Scan Health</span>
                    </Link>
                </div>

                <WeatherWidget />

                {/* Risk Meter with simulated data for demonstration */}
                <RiskMeter
                    humidity={weatherData.humidity}
                    temp={weatherData.temp}
                    rainIn24Hours={weatherData.rainIn24Hours}
                />

                <AddBatchForm />
                <BatchList />
            </div>
            <BottomNav />
        </div>
    );
};

export default HarvestPage;
