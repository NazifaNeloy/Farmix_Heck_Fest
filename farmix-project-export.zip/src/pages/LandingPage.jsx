import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import ThreeScene from '../components/ThreeScene';
import { ArrowRight, AlertTriangle, CheckCircle, Database, Sprout } from 'lucide-react';

import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const LandingPage = () => {
    const { language, toggleLanguage, t } = useLanguage();
    const { user } = useAuth();

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.3
            }
        }
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
            y: 0,
            opacity: 1
        }
    };

    const steps = [
        { icon: Database, key: 'workflow.steps.0', color: 'text-blue-500' },
        { icon: AlertTriangle, key: 'workflow.steps.1', color: 'text-farm-warning' },
        { icon: Sprout, key: 'workflow.steps.2', color: 'text-farm-green-500' },
        { icon: CheckCircle, key: 'workflow.steps.3', color: 'text-farm-green-700' },
    ];

    return (
        <div className="min-h-screen bg-farm-white font-sans overflow-x-hidden">
            {/* Navbar */}
            <nav className="p-4 flex justify-between items-center max-w-7xl mx-auto">
                <div className="text-2xl font-bold text-farm-green-900">Farmix</div>
                <div className="flex items-center gap-4">
                    <button
                        onClick={toggleLanguage}
                        className="px-4 py-2 rounded-full bg-farm-green-100 text-farm-green-900 font-semibold hover:bg-farm-green-200 transition-colors"
                    >
                        {language === 'en' ? 'বাংলা' : 'English'}
                    </button>
                    <Link
                        to={user ? "/harvest" : "/auth"}
                        className="px-4 py-2 rounded-full bg-farm-green-500 text-white font-semibold hover:bg-farm-green-600 transition-colors"
                    >
                        {user ? (language === 'en' ? 'My Harvest' : 'আমার ফসল') : (language === 'en' ? 'Login' : 'লগইন')}
                    </Link>
                    <Link
                        to={user ? "/profile" : "/auth"}
                        className="px-4 py-2 rounded-full bg-farm-green-500 text-white font-semibold hover:bg-farm-green-600 transition-colors"
                    >
                        {user ? (language === 'en' ? 'Profile' : 'প্রোফাইল') : (language === 'en' ? 'Login' : 'লগইন')}
                    </Link>
                </div>
            </nav>

            {/* Hero Section */}
            <section className="max-w-7xl mx-auto px-4 py-12 md:py-20 grid md:grid-cols-2 gap-8 items-center">
                <motion.div
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.8 }}
                >
                    <h1 className="text-4xl md:text-6xl font-bold text-farm-green-900 mb-6 leading-tight">
                        {t('hero.headline')}
                    </h1>
                    <p className="text-xl text-gray-600 mb-8">
                        {t('hero.subheadline')}
                    </p>
                    <button className="bg-farm-green-500 text-white px-8 py-4 rounded-xl text-lg font-bold shadow-lg hover:bg-farm-green-700 transition-all flex items-center gap-2">
                        {t('hero.cta')} <ArrowRight />
                    </button>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                    className="h-[400px] w-full bg-farm-green-100/30 rounded-3xl overflow-hidden"
                >
                    <ThreeScene />
                </motion.div>
            </section>

            {/* Workflow Section */}
            <section className="bg-farm-green-50 py-20 px-4">
                <div className="max-w-7xl mx-auto">
                    <motion.h2
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="text-3xl md:text-4xl font-bold text-center text-farm-green-900 mb-16"
                    >
                        {t('workflow.title')}
                    </motion.h2>

                    <motion.div
                        variants={containerVariants}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true }}
                        className="grid grid-cols-1 md:grid-cols-4 gap-8"
                    >
                        {steps.map((step, index) => {
                            const Icon = step.icon;
                            return (
                                <motion.div
                                    key={index}
                                    variants={itemVariants}
                                    className="bg-white p-8 rounded-2xl shadow-md text-center hover:shadow-xl transition-shadow"
                                >
                                    <div className={`mx-auto w-16 h-16 rounded-full bg-gray-50 flex items-center justify-center mb-6 ${step.color}`}>
                                        <Icon size={32} />
                                    </div>
                                    <h3 className="text-xl font-bold text-gray-900 mb-2">{t(`${step.key}.title`)}</h3>
                                    <p className="text-gray-600">{t(`${step.key}.desc`)}</p>
                                </motion.div>
                            );
                        })}
                    </motion.div>
                </div>
            </section>
        </div>
    );
};

export default LandingPage;
