import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import BadgeCase from '../components/BadgeCase';
import { User, MapPin, Phone, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import BottomNav from '../components/BottomNav';

const ProfilePage = () => {
    const { userData, logout } = useAuth();
    const { t } = useLanguage();
    const navigate = useNavigate();

    const handleLogout = async () => {
        await logout();
        navigate('/');
    };

    if (!userData) {
        return <div className="p-8 text-center">Loading profile...</div>;
    }

    return (
        <div className="min-h-screen bg-farm-green-50 p-4 pb-20">
            <div className="max-w-md mx-auto space-y-6">
                {/* Header */}
                <div className="flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-farm-green-900">My Profile</h1>
                    <button
                        onClick={handleLogout}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors"
                    >
                        <LogOut size={24} />
                    </button>
                </div>

                {/* Profile Card */}
                <div className="bg-white p-6 rounded-3xl shadow-sm">
                    <div className="flex items-center gap-4 mb-6">
                        <div className="w-20 h-20 bg-farm-green-100 rounded-full flex items-center justify-center text-farm-green-700">
                            <User size={40} />
                        </div>
                        <div>
                            <h2 className="text-xl font-bold text-gray-900">{userData.name}</h2>
                            <p className="text-gray-500 text-sm">Farmer</p>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="flex items-center gap-3 text-gray-600">
                            <Phone size={20} className="text-farm-green-500" />
                            <span>{userData.phone}</span>
                        </div>
                        <div className="flex items-center gap-3 text-gray-600">
                            <MapPin size={20} className="text-farm-green-500" />
                            <span>{userData.location || "Location not set"}</span>
                        </div>
                    </div>
                </div>

                {/* Badge Case */}
                <BadgeCase badges={userData.badges} />

                {/* Stats (Placeholder) */}
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-farm-green-500 text-white p-4 rounded-2xl">
                        <div className="text-3xl font-bold mb-1">0</div>
                        <div className="text-sm opacity-90">Crops Saved</div>
                    </div>
                    <div className="bg-white p-4 rounded-2xl shadow-sm">
                        <div className="text-3xl font-bold text-farm-green-900 mb-1">0</div>
                        <div className="text-sm text-gray-500">Active Batches</div>
                    </div>
                </div>
            </div>
            <BottomNav />
        </div>
    );
};

export default ProfilePage;
