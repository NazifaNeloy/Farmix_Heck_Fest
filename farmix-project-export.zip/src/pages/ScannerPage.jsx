import React from 'react';
import Scanner from '../components/Scanner';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import BottomNav from '../components/BottomNav';

const ScannerPage = () => {
    return (
        <div className="min-h-screen bg-black text-white p-4">
            <div className="max-w-md mx-auto">
                <div className="flex items-center gap-4 mb-6">
                    <Link to="/" className="p-2 bg-gray-800 rounded-full hover:bg-gray-700 transition-colors">
                        <ArrowLeft size={20} />
                    </Link>
                    <h1 className="text-xl font-bold">Crop Health Scanner</h1>
                </div>

                <div className="mb-6 text-center">
                    <p className="text-gray-400 text-sm">
                        Point your camera at the crop to detect diseases or mold instantly.
                    </p>
                </div>

                <Scanner />
            </div>
            <BottomNav />
        </div>
    );
};

export default ScannerPage;
