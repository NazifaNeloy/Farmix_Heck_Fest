import axios from 'axios';

const API_KEY = import.meta.env.VITE_OPENWEATHER_API_KEY;
const BASE_URL = 'https://api.openweathermap.org/data/2.5';

export const fetchForecast = async (district) => {
    if (!API_KEY) {
        console.warn("OpenWeatherMap API Key is missing!");
        // Return mock data if key is missing for demo purposes
        return getMockData();
    }

    try {
        const response = await axios.get(`${BASE_URL}/forecast`, {
            params: {
                q: district,
                units: 'metric',
                appid: API_KEY
            }
        });
        return processWeatherData(response.data);
    } catch (error) {
        console.error("Error fetching weather:", error);
        return getMockData();
    }
};

const processWeatherData = (data) => {
    // Group by day and take noon forecast
    const daily = [];
    const seenDates = new Set();

    for (const item of data.list) {
        const date = item.dt_txt.split(' ')[0];
        if (!seenDates.has(date)) {
            seenDates.add(date);
            daily.push(item);
            if (daily.length === 5) break;
        }
    }

    return daily.map(item => ({
        date: new Date(item.dt * 1000).toLocaleDateString('en-US', { weekday: 'short', day: 'numeric' }),
        temp: Math.round(item.main.temp),
        rainChance: item.pop * 100, // Probability of precipitation
        condition: item.weather[0].main,
        icon: item.weather[0].icon,
        advisory: generateAdvisory(item.main.temp, item.pop * 100)
    }));
};

const generateAdvisory = (temp, rainChance) => {
    if (rainChance > 80) {
        return {
            text: "আগামী ৩ দিন বৃষ্টি ৮৫% → আজই ধান কাটুন",
            type: "danger"
        };
    }
    if (temp > 35) {
        return {
            text: `তাপমাত্রা ${Math.round(temp)}°C → ছায়ায় রাখুন`,
            type: "warning"
        };
    }
    return {
        text: "আবহাওয়া অনুকূল আছে",
        type: "success"
    };
};

const getMockData = () => {
    return [
        { date: 'Today', temp: 36, rainChance: 10, condition: 'Clear', icon: '01d', advisory: { text: "তাপমাত্রা ৩৬°C → ছায়ায় রাখুন", type: "warning" } },
        { date: 'Tomorrow', temp: 32, rainChance: 90, condition: 'Rain', icon: '10d', advisory: { text: "আগামী ৩ দিন বৃষ্টি ৮৫% → আজই ধান কাটুন", type: "danger" } },
        { date: 'Wed 30', temp: 28, rainChance: 40, condition: 'Clouds', icon: '03d', advisory: { text: "আবহাওয়া অনুকূল আছে", type: "success" } },
        { date: 'Thu 01', temp: 29, rainChance: 20, condition: 'Clear', icon: '01d', advisory: { text: "আবহাওয়া অনুকূল আছে", type: "success" } },
        { date: 'Fri 02', temp: 30, rainChance: 0, condition: 'Clear', icon: '01d', advisory: { text: "আবহাওয়া অনুকূল আছে", type: "success" } },
    ];
};
