export const calculateETCL = (humidity, temp, rainIn24Hours) => {
    let etcl = 120; // Base: 5 days (120 hours)

    // High Heat & Humidity Rule
    if (humidity > 80 && temp > 30) {
        etcl = 72; // Reduced to 3 days
    }

    // Rain Forecast Rule
    if (rainIn24Hours) {
        etcl -= 24; // Reduce by 1 day
    }

    return Math.max(0, etcl); // Ensure not negative
};

export const getRiskLevel = (etcl) => {
    if (etcl <= 48) return 'High';
    if (etcl <= 96) return 'Medium';
    return 'Low';
};

export const getRiskColor = (level) => {
    switch (level) {
        case 'High': return 'text-red-600 bg-red-100 border-red-200';
        case 'Medium': return 'text-orange-600 bg-orange-100 border-orange-200';
        case 'Low': return 'text-green-600 bg-green-100 border-green-200';
        default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
};
