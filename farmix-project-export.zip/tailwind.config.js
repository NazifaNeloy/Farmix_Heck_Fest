/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        farm: {
          green: {
            100: '#e8f5e9',
            500: '#4caf50',
            700: '#2e7d32',
            900: '#1b5e20',
          },
          earth: '#795548',
          warning: '#ff9800',
          danger: '#f44336',
          white: '#ffffff',
        }
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'], // Will need to import Inter
      }
    },
  },
  plugins: [],
}

